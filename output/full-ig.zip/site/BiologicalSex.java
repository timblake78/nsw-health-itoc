package http://fhir.health.nsw.gov.au/fhir/ehealth/itoc/v1.0/ImplementationGuide/nswhealth-itoc;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class BiologicalSex {

}
