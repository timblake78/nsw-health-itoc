package http://fhir.health.nsw.gov.au/fhir/ehealth/itoc/v1.0/ImplementationGuide/nsw.health.fhir.toc;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class MedicationCheckUndertaken {

}
